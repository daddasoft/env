import setuptools

setuptools.setup(name='Distutils',
                 version='1.0',
                 description='Python env Manager',
                 author='Dadda Hicham',
                 author_email='studio.dadda@gmail.com',
                 url='https://www.daddasoft.xom',
                 )
